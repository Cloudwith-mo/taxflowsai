import os
import json
import boto3
from boto3.dynamodb.conditions import Key

# — use the high-level Dynamo resource to make Query easy
dynamodb = boto3.resource('dynamodb')
table    = dynamodb.Table(os.environ['METADATA_TABLE'])
s3       = boto3.client('s3')
BUCKET   = os.environ['BUCKET_NAME']

def lambda_handler(event, context):
    # 1) grab query params
    params   = event.get('queryStringParameters') or {}
    user     = params.get('user')
    partner  = params.get('partner')
    category = params.get('category')
    
    if not user:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing required query param: user'})
        }
    
    # 2) query DynamoDB for that user (user is the partition key)
    resp = table.query(
        KeyConditionExpression=Key('user').eq(user),
        ScanIndexForward=False   # newest first
    )
    items = resp.get('Items', [])
    
    # 3) optionally filter partner/category
    if partner:
        items = [i for i in items if i.get('partner') == partner]
    if category:
        items = [i for i in items if i.get('category') == category]
    
    # 4) build a simple JSON list
    results = []
    for i in items:
        # if you want to return a presigned GET URL for each S3 key:
        url = s3.generate_presigned_url(
            ClientMethod='get_object',
            Params={'Bucket': BUCKET, 'Key': i['s3Key']},
            ExpiresIn=3600
        )
        results.append({
            'docId':     i['docId'],
            'filename':  i['filename'],
            'status':    i['status'],
            'timestamp': i['timestamp'],
            's3Key':     i['s3Key'],
            'downloadUrl': url
        })
    
    # 5) respond with CORS on
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type':                'application/json',
            'Access-Control-Allow-Origin': '*',            # allow from anywhere
            'Access-Control-Allow-Methods':'GET,OPTIONS'
        },
        'body': json.dumps(results)
    }
